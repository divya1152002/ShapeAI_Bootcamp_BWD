import React from "react";

function Note() {
  return(
    <div classNme="note">
<h1>  ShapeAI Javascript and React.js</h1>
<p> Hi I made this project during the 7 days Free Bootcamp,conducted by  SHAPEAI. The instructor during the session was Mr.Shaurya Sinha(Data Analyst inter at JIO). I got a lot during these 7 days and it was an amazing with SHAPEAI.during 7 days everthing was explaned from the very basic so that anyone with zero experiance on programming can learn. I enjoyed these 7 days .
  </p></div>
    

    

  );
}
export default Note;